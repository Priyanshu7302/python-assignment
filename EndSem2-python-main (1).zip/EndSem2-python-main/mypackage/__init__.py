from .list1 import append1, extend1, pop1, remove1
from .set2 import slen2, adds2, remove2
from .dict3 import len3, add3, keys3, values3
