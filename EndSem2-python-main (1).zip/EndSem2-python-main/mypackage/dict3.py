def len3(d): return len(d)

def add3(d, k, v): d[k] = v

def keys3(d): return d.keys()

def values3(d): return d.values()