def append1(lst, x): lst.append(x)

def extend1(lst, l): lst.extend(l)

def pop1(lst): return lst.pop()

def remove1(lst, x): lst.remove(x)