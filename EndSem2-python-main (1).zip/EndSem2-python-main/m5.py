# cal1 use karke calculation
import cal1

if __name__ == '__main__':
    print(cal1.add1(5,3))
    print(cal1.sub1(5,3))
    print(cal1.mul1(5,3))
    print(cal1.div1(5,3))
    print(cal1.mod1(5,3))
    print(cal1.pow1(5,3))