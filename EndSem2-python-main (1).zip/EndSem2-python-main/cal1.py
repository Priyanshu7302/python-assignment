def add1(x,y): return x+y

def sub1(x,y): return x-y

def mul1(x,y): return x*y

def div1(x,y): return x/y

def mod1(x,y): return x%y

def pow1(x,y): return x**y